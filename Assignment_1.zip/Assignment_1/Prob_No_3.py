#Author : Shivam V. Verma
#Problem No.: 3
#Problem Statement : Take an integer input and print the sum of its digits using while loop

print("\n\t","*"*25,  "Sum of integer digits using while loop","*"*25) 
print("\n")
choice = int(input("Enter your input : "))                              #user integer input
sum = 0                                                                 #declaring sum variable

while(choice > 0):                                                      #while loop to find sum of digits of given integer
    rem = choice % 10                                                   #finding sum                        
    sum = sum + rem                                                     #calculating sum
    choice = choice // 10                                               

print("\n\tSum of digits of given input is : ", sum)                    #printing sum

#Output:
#         ************************* Sum of integer digits using while loop *************************


#Enter your input : 43553444534

#        Sum of digits of given input is :  44

#-----------------------------------------------------* EOP *------------------------------------------------------------------