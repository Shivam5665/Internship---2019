#Author : Shivam V. Verma
#Problem No.: 16
#Problem Statement : Explain what are lambda functions with the following example :

print("\n\t", "*"*25, "Lambda Functions", "*"*25)

'''
Explaination of lambda functions -->
Anonymous functions are the functions that do not have name 
def keyword is normally used to define normal functions whereas lambda functions are used to define anonymous functions
Lambda functions are used with various built_in modules in python such as map(), reduce(), filter(), etc
'''

#Given example:
fun=lambda x,y:3*x**2+2*y+1      #Here x & y variables are assigned and an expression is declared
print("\n\tOutput of lambda function : ",fun(3,2))   #function fun is called by passing values 3 & 2 of x & y resp.

#Thus here we can see that lambda functions are used to define functions with no names

#if the same expression was needed to be solved using def :

def func(x,y):
    exp = 3*x**2+2*y+1
    print("\n\tOutput of def function : ",exp)
func(3,2)

#Example of lambda functions using built_in modules in python such as map(), reduce(), filter(), etc
#1.map() with python

ls = [12,3,53,2,13,55,45,2,15,6,67,10,3]
map_list = list(map(lambda x:x**2, ls))     #squaring elements in the list
print("\n\tSquared list : ",map_list)

#2.filter() with python

filter_list = list(filter(lambda x: (x%5 != 0), ls))  #removing multiples of 5 from list
print("\n\tFiltered List : ",filter_list)    

#3.reduce() with python

from functools import reduce
sum_res = reduce((lambda x, y: x + y), ls)      #sum of elements in list
print("\n\tSum of elements in list : ",sum_res) 

#Output:
'''

         ************************* Lambda Functions *************************

        Output of lambda function :  32

        Output of def function :  32

        Squared list :  [144, 9, 2809, 4, 169, 3025, 2025, 4, 225, 36, 4489, 100, 9]

        Filtered List :  [12, 3, 53, 2, 13, 2, 6, 67, 3]

        Sum of elements in list :  286
'''

#-------------------------------------------------------* EOP *-------------------------------------------------------------------