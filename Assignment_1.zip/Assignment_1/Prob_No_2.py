#Author : Shivam V. Verma
#Problem No.: 2
#Problem Statement : Write a program to take 10 integer values as input from user, store in a list and sort them
#using bubble sort mechanism. Copy the sorted list in another list and print.

list1 = []                                                    #Initial List
list2 = []                                                    #New list

print("\n\t","*"*25, "Sorting And Creating New List", "*"*25)
print("\n\tEnter 10 integer values -->\n")
for i in range(10):
    n = int(input("Enter your number: "))
    list1.append(n)
print("\n\tInitial List : ",list1)                            #printing initial list

temp = 0                                                      #Initializing temporary variable
def bubbleSort(list):                                         #Function to sort string using bubble sort
    for i in range(len(list)-1,0,-1):
        for j in range(i):
            if list[j]>list[j+1]:
                temp = list[j]                               #shifting larger integer to right and smaller to left
                list[j] = list[j+1]
                list[j+1] = temp
bubbleSort(list1)
print("\n\tSorted List: ",list1)                             #printing sorted list

list2 = list1
print("\n\tNew List: ", list2)                               #printing new list containing data of old list

#Output:
#         ************************* Sorting And Creating New List *************************

#        Enter 10 integer values -->

#Enter your number: 3
#Enter your number: 5
#Enter your number: 6
#Enter your number: 7
#Enter your number: 1
#Enter your number: 2
#Enter your number: 0
#Enter your number: 9
#Enter your number: 6
#Enter your number: 4

#        Initial List :  ['3', '5', '6', '7', '1', '2', '0', '9', '6', '4']

#        Sorted List:  ['0', '1', '2', '3', '4', '5', '6', '6', '7', '9']

#        New List:  ['0', '1', '2', '3', '4', '5', '6', '6', '7', '9']


#--------------------------------------------------------* EOP *--------------------------------------------------------------------