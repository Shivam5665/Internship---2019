#Author : Shivam V. Verma
#Problem No.: 13
#Problem Statement : Create a module that contains 2 functions showsquare() and calcsum(). import the
#module in a python program and call the functions

def showsquare(n):
    sqr = ("Square of",n,"is",n*n)
    return sqr

def calcsum(a,b):   
    sum_new= ("Sum of",a,"and",b,"is",a+b)
    return sum_new
