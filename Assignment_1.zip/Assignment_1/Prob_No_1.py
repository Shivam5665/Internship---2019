#Author : Shivam V. Verma
#Problem No.: 1
#Problem Statement : Demonstrate string functions in python


'''Python's built-in string classes support sequence type methods described in the Sequence Types
 — str, unicode, list, tuple, bytearray, buffer, xrange section, and also the string-specific methods 
 described in the String Methods section
 Python treats single quotes the same as double quotes'''

print("\n\t", "*"*25,"Demonstrate string functions in python", "*"*25)

#------------------------------------------------------------------------------------------------------------------------------
#Example1: Initialization of strings in python

print("\n\t\t Initialization of strings in python\n")
str1 = 'Single quotes'
str2 = "Double quotes"
print(str1)
print(str2)
print("Both", str1,"and", str2 , "are same here")
print("\n")

#Output:
#         Initialization of strings in python
#Single quotes
#Double quotes
#Both Single quotes and Double quotes are same here

#-------------------------------------------------------------------------------------------------------------------------------
#Example2: Use of str() method using class and objects

class Node:
    def __init__(self, str1, str2):
        self.str1 = str1
        self.str2 = str2

    def concatination(self):                        #Function to concatinate strings
        res = (self.str1 + self.str2)
        return res
    
    def __str__(self):                              #Function to print strings
        result = self.concatination()
        print("Result : ", result)

print("\t\t Use of str() method using class and objects\n")
str1 = input("Enter First String: ")
str2 = input("Enter Second String: ")
obj = Node(str1, str2)
obj.__str__()
        
#Output:
#         Use of str() method using class and objects
#Enter First String: Hello
#Enter Second String: world
#Result :  Helloworld

#-----------------------------------------------------------------------------------------------------------------------------
#Example3: Use of String methods - len(), upper(), lower(), count(), find(), replace()

print("\n\t\t Use of string methods\n")
str1 = "Czechoslovsakia is quite complicated name!"
print("Length of string is ", len(str1))                        #Length of string
print("Lowercase version : ", str1.lower())                     #converting string to lowercase
print("Uppercase version : ", str1.upper())                     #converting string to uppercase
print("Occurence of c in str : ", str1.count("c"))              #Counting occurence of c's
print("Position of quite in str : ", str1.find("quite"))        #Finding position of "quite" in string
str2 = str1.replace("complicated", "lengthy")                   #replacing "Complicated" with "lengthy" in string
print("Updated string : ", str2)                                #printing updated string

#Output:
#         Use of string methods
#Length of string is  42
#Lowercase version :  czechoslovsakia is quite complicated name!
#Uppercase version :  CZECHOSLOVSAKIA IS QUITE COMPLICATED NAME!
#Occurence of c in str :  3
#Position of quite in str :  19
#Updated string :  Czechoslovsakia is quite lengthy name!

#--------------------------------------------------------* EOP *------------------------------------------------------------------