#Author : Shivam V. Verma
#Problem No.: 17
#Problem Statement : Write a program for simple exception handling with try, except and finally

print("\n\t", "*"*25, "Exception Handling", "*"*25)

#Built-in errors are the one that are defined in the module exceptions by the system itself
print("\n\tBuilt-in Exception --> ")
def  divide ( x ,  y ): 
    try : 
         result  =  x  /  y 
    except  ZeroDivisionError : 
        print ( "\nDivision by zero!" ) 
    else : 
        print( "\nResult is" ,  result ) 
    finally : 
        print ( "Executing finally clause" ) 
 
divide(2,1)                                          #simple division operation 
divide(2,0)                                          #division by zero will invoke the except clause

#User-defined exceptions are the ones that we define inside our program as per our requirements
#User-defined exceptions
class Error(Exception):
   """Base class for other exceptions"""
   pass

#Define class for NegativeValueError
class NegativeValueError(Error):
  """Raised when the input is negative"""
  pass

#Define class for ValueTooSmallError
class ValueTooSmallError(Error):
   """Raised when the value is too small"""
   pass

#Define class for ValueTooLargeError
class ValueTooLargeError(Error):
   """Raised when the value is too large"""
   pass

#main program
#Takes input till the user inputs correct value

#Stored number
number = 100

while True:
   try:
       num = int(input("\nEnter a number: "))
       if num < 0:
           raise NegativeValueError
       elif num < number:
           raise ValueTooSmallError
       elif num > number:
           raise ValueTooLargeError
       break
   except NegativeValueError:
       print("\nThis is a negative value, try again")
       print("")
   except ValueTooSmallError:
       print("\nThis value is too small, try again")
       print("")
   except ValueTooLargeError:
       print("\nThis value is too large, try again!")
       print("")

print("\nHooray! Correct value entered")

#Output:
'''
         ************************* Exception Handling *************************

        Built-in Exception --> 

Result is 2.0
Executing finally clauseprint("\n\t", "*"*25, "Exception Handling", "*"*25)


Division by zero!
Executing finally clause

Enter a number: 13

This value is too small, try again


Enter a number: -1  

This is a negative value, try again


Enter a number: 1000

This value is too large, try again!


Enter a number: 100

Hooray! Correct value entered
'''

#-----------------------------------------------------------* EOP *--------------------------------------------------------------