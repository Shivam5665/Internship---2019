#Author : Shivam V. Verma
#Problem No.: 12
#Problem Statement : Write a program to accept full name in a list and sort the list on their last names.

print("\n\t", "*"*25, "List Sort", "*"*25)

class People:
        def __init__(self, fname, lname):                                               #Initializing first & last name
                self.fname = fname
                self.lname = lname
        
        def __repr__(self):
                return repr((self.fname, self.lname))

while(True):
    ch = input("\n\tDo you wanna continue?(y/n) : ")
    if ch == "y":
        name_list = []                                                                      #declaring empty list
        n = int(input("\nEnter length of list : "))                                           #defining length of list
        print("\nEnter fullname below(ex : Louis Denken)")
        for i in range(n):
            fullname = input("\nEnter fullname : ")
            print("\n")
            fname = fullname.split()[0]
            lname = fullname.split()[1]
            print("\nAppending",fname ,lname ,"in list..." )
            name_list.append(People(fname,lname))                                            #Appending data into list
            print("\nAppended",fname ,lname ,"in list successfully" )                                        
        print("\n\tList :",name_list)

        print("\n\tSorted List : ",sorted(name_list, key=lambda People: People.lname))      #printing sorted list
    else:
        print("\n\tExiting Program...")
        break
        
#Output:
'''
         ************************* List Sort *************************

        Do you wanna continue?(y/n) : y

Enter length of list : 5

Enter fullname below(ex : Louis Denken)

Enter fullname : ethan hunt



Appending ethan hunt in list...

Appended ethan hunt in list successfully

Enter fullname : mohd salah



Appending mohd salah in list...

Appended mohd salah in list successfully

Enter fullname : edan hazard



Appending edan hazard in list...

Appended edan hazard in list successfully

Enter fullname : david luiz



Appending david luiz in list...

Appended david luiz in list successfully

Enter fullname : amir khan



Appending amir khan in list...

Appended amir khan in list successfully

        List : [('ethan', 'hunt'), ('mohd', 'salah'), ('edan', 'hazard'), ('david', 'luiz'), ('amir', 'khan')]

        Sorted List :  [('edan', 'hazard'), ('ethan', 'hunt'), ('amir', 'khan'), ('david', 'luiz'), ('mohd', 'salah')]

        Do you wanna continue?(y/n) : n

        Exiting Program...
'''

#--------------------------------------------------* EOP *-------------------------------------------------------------------------