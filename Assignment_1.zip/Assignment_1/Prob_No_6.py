#Author : Shivam V. Verma
#Problem No.: 6
#Problem Statement : What is mutable collection?

print("\n\t", "*"*25, "Mutable Collections", "*"*25)

print("\n\t--> List: ")
ls_user = ["Shivam", "Verma", "MITAOE", "IT"]
print("\n list : ",ls_user)
ls_user[3] = "CS"   
print("\nUpdated List : ",ls_user)

print("\n\t--> Dictionary: ")
dict_user = {"Name":"Shivam", "Lname":"Verma", "Clg":"MITAOE", "Dept":"IT" }
print(dict_user)
dict_user["Dept"] = "CS"
print(dict_user)

print("\n\t--> Sets: ")
s = set([123, 456, 789])
r = s
r |= set([1,2,3])
print("set s : ", s)
print("set r : ", r)

#Output:
'''         ************************* Mutable Collections *************************

        --> List: 

 list :  ['Shivam', 'Verma', 'MITAOE', 'IT']

Updated List :  ['Shivam', 'Verma', 'MITAOE', 'CS']

        --> Dictionary: 
{'Name': 'Shivam', 'Lname': 'Verma', 'Clg': 'MITAOE', 'Dept': 'IT'}
{'Name': 'Shivam', 'Lname': 'Verma', 'Clg': 'MITAOE', 'Dept': 'CS'}

        --> Sets: 
set s :  {1, 2, 3, 789, 456, 123}
set r :  {1, 2, 3, 789, 456, 123}
'''

#-----------------------------------------------------* EOP *--------------------------------------------------------