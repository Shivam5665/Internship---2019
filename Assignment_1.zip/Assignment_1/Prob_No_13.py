#Author : Shivam V. Verma
#Problem No.: 13
#Problem Statement : Create a module that contains 2 functions showsquare() and calcsum(). import the
#module in a python program and call the functions

from Import_module_13 import *                                                          #importing all modules from Import_module_13
print("\n\t", "*"*25, "Calling Python functions", "*"*25)

while(True):
    print("\n\tChoose any one :\n\t1.Square Calculator\n\t2.Sum Calculator\n\t3.Exit")
    choice = int(input("\nWhich operation would you like to choose? : "))               #user input to choose operation of his choice
    if choice == 1:
        n = int(input("Enter your number : "))
        print(showsquare(n))                                                            #calling showsquare function from Import_module_13
    elif choice == 2:   
        a = input("Enter first number : ")
        b = input("Enter second number : ")
        print(calcsum(a,b))                                                             #calling calcsum function from Import_module_13
    else:
        print("\nExiting Program...")
        break

#Output:
'''

         ************************* Calling Python functions *************************

        Choose any one :
        1.Square Calculator
        2.Sum Calculator
        3.Exit

Which operation would you like to choose? : 1
Enter your number : 323231
('Square of', 323231, 'is', 104478279361)

        Choose any one :
        1.Square Calculator
        2.Sum Calculator
        3.Exit

Which operation would you like to choose? : 2
Enter first number : 4422
Enter second number : 3232
('Sum of', '4422', '3232', 'is', '44223232')

        Choose any one :
        1.Square Calculator
        2.Sum Calculator
        3.Exit

Which operation would you like to choose? : 3

Exiting Program...
'''

#-------------------------------------------------* EOP *-----------------------------------------------------------------