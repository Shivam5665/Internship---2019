#Author : Shivam V. Verma
#Problem No.: 8
#Problem Statement : What is a frozenset?

print("\n\t", "*"*25, "FrozenSets", "*"*25)

set_user = frozenset(["Shivam", "Verma", "MITAOE", "IT"])
print("\n\t Syntax of Frozenset : ",set_user)

#set_user.add("B502")        As Frozen sets are immutable, it cannot be updated
#print(set_user)             Hence add, remove functions will give error 

set_user1 = frozenset(["Vaibhav", "Saini", "PCCOE", "IT"])

print("\n\t Union result : ", set_user|set_user1)                             #Union Method

print("\n\t Intersection result : ", set_user.intersection(set_user1))        #Intersection Method

print("\n\t Difference result : ", set_user.difference(set_user1))            #Difference Method

#Output:
'''
        ************************* FrozenSets *************************

         Syntax of Frozenset :  frozenset({'Verma', 'MITAOE', 'IT', 'Shivam'})

         Union result :  frozenset({'Vaibhav', 'Shivam', 'Verma', 'MITAOE', 'IT', 'Saini', 'PCCOE'})

         Intersection result :  frozenset({'IT'})

         Difference result :  frozenset({'Verma', 'MITAOE', 'Shivam'})
'''

#-----------------------------------------------------------* EOP *-----------------------------------------------------------------