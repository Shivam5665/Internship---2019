#Author : Shivam V. Verma
#Problem No.: 11
#Problem Statement : Define a function in a python program that receives purchase amount and discount to
#display net bill

print("\n\t", "*"*25, "Customer's Receipt", "*"*25)
class Shop_Bill:

    def bill_calc(self,amt,act_dis,tax):                                        #Bill Calculation function
        tot_amt = int(amt - act_dis + tax)                                   #calculating total purchase amount
        return tot_amt                                                          #returning total purchase amount


def main():
    ob = Shop_Bill()                                                            #creating instance of Shop_Bill class
    while(True):
        choice = input("Do you wanna create bill(y/n) : ")
        if choice == "y":
            print("\nEnter bill details --> \n")    
            amt = int(input("Enter total purchase amount : "))                  #Actual purchase amount
            dis = int(input("Enter discount(%) : "))                            #Discount 
            act_dis = (dis*amt)/100                                             #Discount in terms of Rs.
            ch = input("Do you wanna include any tax(y/n) : ")                  #Condition to decide whether to include tax or not       
            ch.islower()
            tax = 0
            if ch == "y":
                tax = int(input("Enter tax(%) : "))                             #User input for tax value
            else:
                tax = 0
            
            print("\nEnter personal details --> \n")
            name = input("Enter your name : ")                                  
            mob_no = int(input("Enter your mobile No. : "))
            city = input("Enter city : ")         

            print("\nPrinting Receipt...\n")
            print("-"*120)
            print("\n\t","*"*25,"Bill Receipt","*"*25)
            print("\n\t","Customer name: ",name,"\n\t","Mobile No. : ",mob_no,"\n\t","City : ",city)
            print("\n\t Purchase Amout : ",amt,"Rs.")
            print("\n\t Discount : ",act_dis,"Rs.")
            print("\n\t Tax : ",tax,"Rs.")
            print("\n\t Total Purchase Amount : ",ob.bill_calc(amt,act_dis,tax),"Rs.")
            print("\n\t","*"*25,"Thank You!","*"*25)
            print("-"*120)
        else:
            print("\n\tExiting Program ...")
            break

if __name__== "__main__":
    main()

#Output:
'''

         ************************* Customer's Receipt *************************
Do you wanna create bill(y/n) : y

Enter bill details --> 

Enter total purchase amount : 20000
Enter discount(%) : 20
Do you wanna include any tax(y/n) : y
Enter tax(%) : 12

Enter personal details --> 

Enter your name : Rob Stark
Enter your mobile No. : 1231231231
Enter city : LA

Printing Receipt...

------------------------------------------------------------------------------------------------------------------------

         ************************* Bill Receipt *************************

         Customer name:  Rob Stark 
         Mobile No. :  1231231231 
         City :  LA

         Purchase Amout :  20000 Rs.

         Discount :  4000.0 Rs.

         Tax :  12 Rs.

         Total Purchase Amount :  16012 Rs.

         ************************* Thank You! *************************
------------------------------------------------------------------------------------------------------------------------
Do you wanna create bill(y/n) : n

        Exiting Program ...
'''

#----------------------------------------------------* EOP *----------------------------------------------------------------