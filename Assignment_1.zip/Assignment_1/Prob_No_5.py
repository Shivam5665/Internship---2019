#Author : Shivam V. Verma
#Problem No.: 5
#Problem Statement : What is the difference between List and Tuple? Explain working of a tuple with a program.

print("\n\t", "*"*25, "Difference between List and Tuple", "*"*25, "\n")
#--------------------------------------------------------------------------------------------------------------------------------
#1. Syntax:

print("\n\t --> Syntax")
ls_user = ["Shivam", "Verma", "MITAOE", "IT"]
print("\nSyntax of list : ",ls_user)

tp_user = ("Shivam", "Verma", "MITAOE", "IT")
print("\nSyntax of Tuple : ",tp_user)

#Output:
#Syntax of list :  ['Shivam', 'Verma', 'MITAOE', 'IT']
#Syntax of Tuple :  ('Shivam', 'Verma', 'MITAOE', 'IT')
#---------------------------------------------------------------------------------------------------------------------------------
#2. Mutable vs Immutable:

print("\n\t --> Mutability")

ls_user[3] = "CS"   
print("\nUpdated List : ",ls_user)

#tp_user(3) = "CS"                --> Tuples are immutables and hence they cannot be edited once written   
#print(tp_user)

#Output:
#Updated List :  ['Shivam', 'Verma', 'MITAOE', 'CS']
#----------------------------------------------------------------------------------------------------------------------------------
#3. Functionality:

print("\n\t --> Functionlity")

print("\nFunctions of list are : ", dir(ls_user))     #functions of given list
print("\nFunctions of Tuple are : ",dir(tp_user))     #functions of given tuple

#Output:
#Functions of list are :  ['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']

#Functions of Tuple are :  ['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count', 'index']
#---------------------------------------------------------------------------------------------------------------------------------------
#4. Python List of Tuples:

print("\n\t --> Python List of Tuples")

ls_users = [("Shivam", "MITAOE", "IT"), ("Vaibhav", "MITAOE", "IT"), ("Shubham", "MITAOE", "IT")]
print("\nList of Tuples : ", ls_users)
    

#Output:
#List of Tuples :  [('Shivam', 'MITAOE', 'IT'), ('Vaibhav', 'MITAOE', 'IT'), ('Shubham', 'MITAOE', 'IT')]

#-------------------------------------------------------------* EOP *------------------------------------------------------------