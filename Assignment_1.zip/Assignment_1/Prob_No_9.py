#Author : Shivam V. Verma
#Problem No.: 9
#Problem Statement : Create a dictionary of famous people and their countries. Accept a name as an input and
#search if it exists in the dictionary.

print("\n\t", "*"*25, "Dictionary : People & Countries", "*"*25)

dict_p = {"Rob":"US", "Shubham":"India", "Drake":"Germany", "Shawn":"Korea", "Ching Yan":"China", "Ygritte":"UK",} #Initializing Dictionary
print("\n\tDictionary: ",dict_p)                                                                                   #printing Dict

while(True):
    name = input("\nEnter name of person: ")
    if name in dict_p:                                                                                             #checking whether name is present in dict or not
        print("\n\tCountry of", name , "is ", dict_p[name])
    else:
        print("\nSorry!",name,"not present in dictinary")
        break

#Output
'''

         ************************* Dictionary : People & Countries *************************

        Dictionary:  {'Rob': 'US', 'Shubham': 'India', 'Drake': 'Germany', 'Shawn': 'Korea', 'Ching Yan': 'China', 'Ygritte': 'UK'}

Enter name of person: Shawn

        Country of Shawn is  Korea

Enter name of person: Ygritte

        Country of Ygritte is  UK

Enter name of person: Dan

Sorry! Dan not present in dictinary
'''

#-------------------------------------------------------* EOP *----------------------------------------------------------------------