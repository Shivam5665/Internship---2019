    #Author : Shivam V. Verma
    #Problem No.: 18
    #Problem Statement : Accept a line of text, open file in append mode and add it to a text file.

print("\n\t", "*"*25, "File Handling", "*"*25)

while(True):
    ch = input("\nDo you wanna continue?(y/n) : ")
    ch.islower()
    if ch == 'y':
        print("\n\tChoose one operation :\n\t1. Read file\n\t2. Append data into file\n")
        op = int(input("Enter your operation : "))
        if op == 1:
            # a file named "File_handling", will be opened with the reading mode. 
            file = open('File_handling.txt', 'r+') 
            # This will print every line one by one in the file 
            print("\nContents of file --> \n")
            for each in file: 
                print (each) 
        elif op == 2:
            text = input("\nEnter your data to append into the file : ")  
            # a file named "File_handling", will be opened with the appending mode. 
            with open("File_handling.txt", "a+") as file_n:
                file_n.write(text)                                      #this will append user text inside the file
                print("\n",text,"added successfully in file!")

    else:
        print("\nExiting Program...\n")
        break

#Output:
'''
        ************************* File Handling *************************

Do you wanna continue?(y/n) : y

        Choose one operation :
        1. Read file
        2. Append data into file

Enter your operation : 1

Contents of file --> 

Hey, It's me again!

Do you wanna continue?(y/n) : y

        Choose one operation :
        1. Read file
        2. Append data into file

Enter your operation : 2

Enter your data to append into the file : It's nice to meet you Arya!

 It's nice to meet you Arya! added successfully in file!

Do you wanna continue?(y/n) : y

        Choose one operation :
        1. Read file
        2. Append data into file

Enter your operation : 1

Contents of file --> 

Hey, It's me again!It's nice to meet you Arya!

Do you wanna continue?(y/n) : n

Exiting Program...

'''

#------------------------------------------------------------* EOP *------------------------------------------------------------

            

