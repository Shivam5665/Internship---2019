#Author : Shivam V. Verma
#Problem No.: 7
#Problem Statement : write a program to demonstrate working of different operators like difference, union,
#intersection, etc. on given sets


print("\n\t", "*"*25, "Performing Operations on Sets", "*"*25)

lang = set(["java","c#","python","microsoft","oracle"]) #Initializing lang set
print("\nlang set : ", lang)
db = set(["oracle","sql server","mysql","microsoft"])  #Initializing db set
print("\ndb set : ", db)


#Methods for Sets:

#1. Add Method:-

lang.add("kotlin")
print("\nUpdated lang set : ", lang)

db.add("mongodb")
print("\nUpdated db set : ", db)
 
# Remove Method:-
lang.remove("kotlin")
print("\nUpdated lang set : ", lang)

db.remove("mongodb")
print("\nUpdated db set : ", db)

#3. Union Method:-

web = lang.union(db)    #or web = lang|db
print("\nWeb set : ", web)

#4. Intersection Method:-

print("\nIntersection of lang & db : ",lang.intersection(db))

#5. Difference Method:-

print("\nDifference of lang & db : ",lang.difference(db))

#6. Clear Method:-

print("\nLang set(cleared) : ", lang.clear())
print("\ndb set(cleared) : ", db.clear())

#Output:
'''


         ************************* Performing Operations on Sets *************************

lang set :  {'microsoft', 'python', 'c#', 'java', 'oracle'}

db set :  {'oracle', 'mysql', 'sql server', 'microsoft'}

Updated lang set :  {'microsoft', 'python', 'c#', 'java', 'oracle', 'kotlin'}

Updated db set :  {'sql server', 'microsoft', 'mongodb', 'oracle', 'mysql'}

Updated lang set :  {'microsoft', 'python', 'c#', 'java', 'oracle'}

Updated db set :  {'sql server', 'microsoft', 'oracle', 'mysql'}

Web set :  {'sql server', 'microsoft', 'python', 'c#', 'java', 'oracle', 'mysql'}

Intersection of lang & db :  {'oracle', 'microsoft'}

Difference of lang & db :  {'c#', 'python', 'java'}

Lang set(cleared) :  None

db set(cleared) :  None
'''

#----------------------------------------------------* EOP *---------------------------------------------------------------



