#Author : Shivam V. Verma
#Problem No.: 14
#Problem Statement : Create a class that contains data members, constructor and a fuction that displays sum
#of all values in the list passed.

print("\n\t", "*"*25, "Python Class", "*"*25)

class Maths:                                                                    #class maths to define function sum inside it
    def __init__(self):                                                         #constructor to initialize list
        self.ls = []                                                            #defining empty list

    def sum_list(self):                                                         #function sum that returns sum of all numbers in list
        res = 0
        for i in self.ls:                                                       #splitting each term inside list and adding it to res variable
            res = res + i
        return res                                                              #returning res
        

def main():
    obj = Maths()                                                               #creating instance
    while(True):
        ch = (input("\n\tDo you wanna continue?(y/n) : "))
        ch.islower()
        if ch == "y":
            
                n = int(input("\nEnter length of list : "))                     #defining length of list
                for i in range(n):
                    data = int(input("Enter your data : "))
                    obj.ls.append(data)                                         #appending elements into list

                print("Your list : ", obj.ls)
                print("Sum of all elements in list is : ",obj.sum_list())       #calling sum_list function to get output as sum of all numbers in list                        
        else:
            print("\n\tExiting Program...")
            exit()        

if __name__=="__main__":
    main()

#Output:
'''

         ************************* Python Class *************************

        Do you wanna continue?(y/n) : y

Enter length of list : 5
Enter your data : 1 
Enter your data : 2
Enter your data : 3
Enter your data : 4
Enter your data : 5
Your list :  [1, 2, 3, 4, 5]
Sum of all elements in list is :  15

        Do you wanna continue?(y/n) : n

        Exiting Program...
'''

#----------------------------------------------------* EOP *----------------------------------------------------------------