#Author : Shivam V. Verma
#Problem No.: 4
#Problem Statement : Append values to a list and demonstrate important function of List like insert, remove,
#reverse, sort, pop, min, max etc.

#Note : Sort, reverse, max and min functions were not working in my vscode terminal but the program is completely executable
#through external terminal or any other IDE

print("\n\t","*"*25, "Important functions of list", "*"*25, "\n")
ls = []                                                                             #initializing list
print("Initially declaring a list to perform further operations")
n = int(input("Enter length of list : "))                                           #defining length of list
for i in range(n):
        n = input("Enter your data : ")
        ls.append(n)                                                                #appending elements into list

print("Your list : ", ls)

while(True):
    #A menu driven program accessing various functions of list

    print("\n\tChoose your operation:\n\t1. insert\n\t2. remove\n\t3. pop\n\t4. index\n\t5. count\n\t6. sort\n\t7. reverse\n\t8. max\n\t9. min\n\t10. Exit\n")
    choice = int(input("Enter your choice : "))
    if choice == 1:
        item = str(input("Enter your item to insert : "))
        pos = int(input("Enter position : "))
        ls.insert(pos, item)                                            #Inserting items into list at given position
        print("\n\t",item, "inserted successfully!!\n")
        print("\n\t Updated List is : ", ls)
    
    elif choice == 2:
        item = str(input("Enter your item to remove : "))
        if item in ls:
            ls.remove(item)                                             #Removing items from list 
            print("\n\t",item, "removed successfully!!\n")
        else:
            print("\n\t",item ,"not present in list","\n")
        print("\n\t Updated List is : ", ls)

    elif choice == 3:
        pos = int(input("Enter position of element : "))
        if (pos<=len(ls)): 
            item = ls[pos]   
            ls.pop(pos)                                                 #popping out elements present at given position
            print("\n\t",item, "popped out successfully!!\n")
        else:
            print("\n\t",item ,"index out of range","\n")
        print("\n\t Updated List is : ", ls)

    elif choice == 4:
        item = str(input("Enter element to find its index : "))
        occ = int(input("Enter occurence of element : "))
        num = (ls.index(item, occ))                                     #Finding index of given item
        print("Index of", item , "in list is : ",num)

    elif choice == 5:
        item = str(input("Enter element to find its count : "))
        print("Count of", item , "in list is :",ls.count(item))         #finding count of item present in list

    elif choice == 6:
        ls.sort()                                                       #Sorting list
        print("\n\tSorted list is : ", ls)

    elif choice == 7:
        ls.reverse()                                                    #Reversing list
        print("\n\tReversed list is : ", ls)
        
    elif choice == 8:
        print("Largest item in list is : ", max(ls))                    #Finding largest item in list

    elif choice == 9:
        print("Smallest item in list is : ", min(ls))                   #Finding smallest item in list

    else:
        print("Exiting Program...") 
        break                                                           #Closing program

#Output
'''
	 ************************* Important functions of list ************************* 

Initially declaring a list to perform further operations
Enter length of list : 5
Enter your data : sea
Enter your data : dog
Enter your data : car
Enter your data : tree
Enter your data : bike
Your list :  ['sea', 'dog', 'car', 'tree', 'bike']

	Choose your operation:
	1. insert
	2. remove
	3. pop
	4. index
	5. count
	6. sort
	7. reverse
	8. max
	9. min
	10. Exit

Enter your choice : 1
Enter your item to insert : car
Enter position : 3

	 car inserted successfully!!


	 Updated List is :  ['sea', 'dog', 'car', 'car', 'tree', 'bike']

	Choose your operation:
	1. insert
	2. remove
	3. pop
	4. index
	5. count
	6. sort
	7. reverse
	8. max
	9. min
	10. Exit

Enter your choice : 2
Enter your item to remove : bike

	 bike removed successfully!!


	 Updated List is :  ['sea', 'dog', 'car', 'car', 'tree']

	Choose your operation:
	1. insert
	2. remove
	3. pop
	4. index
	5. count
	6. sort
	7. reverse
	8. max
	9. min
	10. Exit

Enter your choice : 3
Enter position of element : 1

	 dog popped out successfully!!


	 Updated List is :  ['sea', 'car', 'car', 'tree']

	Choose your operation:
	1. insert
	2. remove
	3. pop
	4. index
	5. count
	6. sort
	7. reverse
	8. max
	9. min
	10. Exit

Enter your choice : 1
Enter your item to insert : dog
Enter position : 3

	 dog inserted successfully!!


	 Updated List is :  ['sea', 'car', 'car', 'dog', 'tree']

	Choose your operation:
	1. insert
	2. remove
	3. pop
	4. index
	5. count
	6. sort
	7. reverse
	8. max
	9. min
	10. Exit

Enter your choice : 3
Enter position of element : 3

	 dog popped out successfully!!


	 Updated List is :  ['sea', 'car', 'car', 'tree']

	Choose your operation:
	1. insert
	2. remove
	3. pop
	4. index
	5. count
	6. sort
	7. reverse
	8. max
	9. min
	10. Exit

Enter your choice : 4
Enter element to find its index : car
Enter occurence of element : 1
Index of car in list is :  1

	Choose your operation:
	1. insert
	2. remove
	3. pop
	4. index
	5. count
	6. sort
	7. reverse
	8. max
	9. min
	10. Exit

Enter your choice : 5
Enter element to find its count : car
Count of car in list is : 2

	Choose your operation:
	1. insert
	2. remove
	3. pop
	4. index
	5. count
	6. sort
	7. reverse
	8. max
	9. min
	10. Exit

Enter your choice : 6

	Sorted list is :  ['car', 'car', 'sea', 'tree']

	Choose your operation:
	1. insert
	2. remove
	3. pop
	4. index
	5. count
	6. sort
	7. reverse
	8. max
	9. min
	10. Exit

Enter your choice : 7

	Reversed list is :  ['tree', 'sea', 'car', 'car']

	Choose your operation:
	1. insert
	2. remove
	3. pop
	4. index
	5. count
	6. sort
	7. reverse
	8. max
	9. min
	10. Exit

Enter your choice : 8
Largest item in list is :  tree

	Choose your operation:
	1. insert
	2. remove
	3. pop
	4. index
	5. count
	6. sort
	7. reverse
	8. max
	9. min
	10. Exit

Enter your choice : 9
Smallest item in list is :  car

	Choose your operation:
	1. insert
	2. remove
	3. pop
	4. index
	5. count
	6. sort
	7. reverse
	8. max
	9. min
	10. Exit

Enter your choice : 10
Exiting Program...
'''

#-------------------------------------------------------* EOP *--------------------------------------------------------------


