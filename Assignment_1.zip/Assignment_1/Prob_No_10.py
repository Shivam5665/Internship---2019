#Author : Shivam V. Verma
#Problem No.: 10
#Problem Statement : Define an empty dictionary. Accept keys & values in a loop and add them in the
#dictionary as long as user choice is "yes". Print the dictionary.

print("\n\t", "*"*25, "Dictionary : User input insertion", "*"*25)

dict_u = {}                                                                 #Empty Dictionary
while(True):
    ch = input("\n\tAdd entry into dict?(yes/no): ")                        #user input to add into dict
    ch.islower()
    if ch == "yes":                                                         #condition to add into dict
        en = input("\nDo you wanna enter key(y/n): ")
        en.islower()                                                        
        if en == "y":
            key = input("\nEnter key : ")                                   #user key
            val = input("\nEnter value : ")                                 #user value 
            dict_u.update({key:val})                                        #adding key, value into dict
            print("\n\tUpdated dict : ", dict_u)                            #printing updated dictionary
        else:
            key = 1                                                         #auto key input
            val = input("\nEnter value : ")                                 #user value
            dict_u.update({key:val})                                        #adding key, value into dict
            print("\n\tUpdated dict : ", dict_u)                            #printing updated dictionary
            key += 1                                                        #incrementing auto key input by 1
    else:
        print("\n\tExiting program...")
        break

#Ouptut:
'''

         ************************* Dictionary : User input insertion *************************

        Add entry into dict?(y/n): yes

Do you wanna enter key(y/n): y

Enter key : Smartphone    

Enter value : Redmi

        Updated dict :  {'Smartphone': 'Redmi'}

        Add entry into dict?(y/n): y

Do you wanna enter key(y/n): y

Enter key : Laptop

Enter value : hp

        Updated dict :  {'Smartphone': 'Redmi', 'Laptop': 'hp'}

        Add entry into dict?(y/n): y

Do you wanna enter key(y/n): n

Enter value : Random

        Updated dict :  {'Smartphone': 'Redmi', 'Laptop': 'hp', 1: 'Random'}

        Add entry into dict?(y/n): n

        Exiting program...
'''

#------------------------------------------------* EOP *------------------------------------------------------------------------