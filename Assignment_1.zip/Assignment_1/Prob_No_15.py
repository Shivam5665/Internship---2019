#Author : Shivam V. Verma
#Problem No.: 15
#Problem Statement : Write a program to demonstrate multiple inheritance in python

#Multiple inheritance: When a child class inherits from multiple parent classes, it is called as multiple inheritance.

print("\n\t", "*"*25, "Multiple Inheritance", "*"*25)


# Base class1 
class Employee( object ):		                                #class Employee having employee details
    def __init__(self, name, idnumber, salary, post):           #constructor for initializing attributes for an employee
        self.name = name
        self.idnumber = idnumber
        self.salary = salary 
        self.post = post 

#Base class2			
class Customer( object ):
    def __init__(self, bill_no, mob_no, city):                  #constructor for initializing attributes for a customer
        self.bill_no = bill_no
        self.mob_no = mob_no
        self.city = city

# Derived class 
class Person( Employee, Customer ):	                            #Inheririting Employee and Customer class into Person class 

		# __init__ is known as the constructor		 
    def __init__(self, name, idnumber, salary, post, bill_no, mob_no, city):  #initializing all attributes of Employee as well as Customer class
        Employee.__init__(self, name, idnumber, salary, post)
        Customer.__init__(self, bill_no, mob_no, city)

    def display(self):                                          #Displaying result
        print("\n\tProfessional Details --> ")
        print("\nName : ",self.name)
        print("idnumber : ",self.idnumber)
        print("Salary : ",self.salary) 
        print("Post : ",self.post)            
        print("\n\tShopping Details --> ")
        print("\nBill no. : ",self.bill_no)
        print("Mobile No.: ",self.mob_no)
        print("City : ",self.city)

obj_p = Person('Jon','BK1231',30000,'Software Developer', 'JHBK3231',1231231231,'Paris')  #Instance of Person class
obj_p.display()
    
#Output
'''
         ************************* Multiple Inheritance *************************

        Professional Details --> 

Name :  Jon
idnumber :  BK1231
Salary :  30000
Post :  Software Developer

        Shopping Details --> 

Bill no. :  JHBK3231
Mobile No.:  1231231231
City :  Paris
'''

#-----------------------------------------------------* EOP *-----------------------------------------------------------------