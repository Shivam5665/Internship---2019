#Author : Shivam V. Verma
#Assignment No. : 2
#Problem No. : 6
#Problem Statement : to accept account number and if found delete the record from the database. 
# Before the program keep a trigger ready that will copy every deleted record in another table automatically in another table.  

import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode

'''
NOTE : Run the program after inserting the trigger 
--------------------------------------------------- TRIGGER FOR DELETED ACCOUNTS --------------------------------------------------
DELIMITER //
CREATE TABLE deleted_acc(accno int primary key,accnm varchar(30),acctype varchar(10) not null,balance float)//

CREATE TRIGGER del_acc AFTER DELETE
    -> ON accounts
    -> FOR EACH ROW
    -> BEGIN
    -> INSERT INTO deleted_acc
    -> values(old.accno, old.accnm, old.acctype, old.balance);                      
    -> END//
'''
def del_acc(accno):
    try:
        connection = mysql.connector.connect(host='localhost',
                                       database='bankingdb',
                                       user='root',
                                       password='')
        
        cursor = connection.cursor(prepared=True)
        
        sql_select_query = "DELETE FROM accounts WHERE accno = {}".format(accno)
        cursor.execute(sql_select_query)
        print("\nAccount",accno,"deleted successfully\n")
    except mysql.connector.Error as error:
        print("Failed to get record from database: {}".format(error))
    finally:
        # closing database connection.
        if (connection.is_connected()):
            cursor.close()
            connection.close()
            print("\n--> MySQL connection is closed\n")

def get_deleted_acc(accno):
    try:
        connection = mysql.connector.connect(host='localhost',
                                       database='bankingdb',
                                       user='root',
                                       password='')
        
        cursor = connection.cursor(prepared=True)
        
        sql_select_query = "SELECT * FROM deleted_acc WHERE accno = {}".format(accno)
        cursor.execute(sql_select_query)
        record = cursor.fetchall()
        if record == []:
            print("Sorry! Match not found!!")
        else:
            for row in record:
                print("accno = ", row[0], )
                print("accnm = ", row[1])
                print("acctype = ", row[2])
                print("balance  = ", row[3], "\n")
    except mysql.connector.Error as error:
        print("Failed to get record from database: {}".format(error))
    finally:
        # closing database connection.
        if (connection.is_connected()):
            cursor.close()
            connection.close()
            print("\n--> MySQL connection is closed\n")

print("\n\t","*"*25,"Deleted Accounts","*"*25)  
while True:
    ch = input("\n\tDo you wanna continue(y/n) : ")
    if ch == "y":
        print("\n\tChoose any one:\n\t1. Delete account from database\n\t2. Search deleted accounts\n\t3. Exit")
        ch = int(input("\nEnter your choice: "))
        if ch == 1:
            accno = int(input("\nEnter account number to delete : "))
            del_acc(accno)
        elif ch == 2:
            accno = int(input("\nEnter deleted account number to search : "))
            get_deleted_acc(accno)
        else:
            break
    else:
        print("\nExiting Program!!\n")
        break

#Output:
'''

         ************************* Deleted Accounts *************************

        Do you wanna continue(y/n) : y

        Choose any one:
        1. Delete account from database
        2. Search deleted accounts
        3. Exit

Enter your choice: 1

Enter account number to delete : 1005

Account 1005 deleted successfully


--> MySQL connection is closed


        Do you wanna continue(y/n) : y

        Choose any one:
        1. Delete account from database
        2. Search deleted accounts
        3. Exit

Enter your choice: 2

Enter deleted account number to search : 1005
accno =  1005
accnm =  bytearray(b'robert lewandowski')
acctype =  bytearray(b'saving')
balance  =  22248.0 


--> MySQL connection is closed


        Do you wanna continue(y/n) : n

Exiting Program!!
'''
