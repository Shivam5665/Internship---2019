#Author : Shivam V. Verma
#Assignment No. : 2
#Problem No. : 7
#Problem Statement : to enter amount and show all account details having balance less than the specified amount

import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode

def get_acc_details(balance):
    try:
        connection = mysql.connector.connect(host='localhost',
                                       database='bankingdb',
                                       user='root',
                                       password='')
        
        cursor = connection.cursor(prepared=True)
        
        sql_select_query = "SELECT * FROM accounts WHERE balance < {}".format(balance)
        cursor.execute(sql_select_query)
        record = cursor.fetchall()
        if record == []:
            print("Sorry! No entries found below this limit!!")
        else:
            for row in record:
                print("accno = ", row[0], )
                print("accnm = ", row[1])
                print("acctype = ", row[2])
                print("balance  = ", row[3], "\n")
    except mysql.connector.Error as error:
        print("Failed to get record from database: {}".format(error))
    finally:
        # closing database connection.
        if (connection.is_connected()):
            cursor.close()
            connection.close()
            print("\n--> MySQL connection is closed\n")

print("\n\t","*"*25,"Accounts with lower balance","*"*25)  
while True:
    ch = input("\n\tDo you wanna continue(y/n) : ")
    if ch == "y":
        balance = int(input("\nEnter account balance : "))
        get_acc_details(balance)
    else:
        print("\nExiting Program!!\n")
        break

#Output:
'''

         ************************* Accounts with lower balance *************************

        Do you wanna continue(y/n) : y

Enter account balance : 1222 
Sorry! No entries found below this limit!!

--> MySQL connection is closed


        Do you wanna continue(y/n) : y   

Enter account balance : 1333333
accno =  1001
accnm =  bytearray(b'sachin tendulkar')
acctype =  bytearray(b'saving')
balance  =  45000.0 

accno =  1002
accnm =  bytearray(b'maria sharapova')
acctype =  bytearray(b'fixed')
balance  =  23100.0 

accno =  1003
accnm =  bytearray(b'mitchell johnson')
acctype =  bytearray(b'current')
balance  =  15300.0 

accno =  1004
accnm =  bytearray(b'edan hazard')
acctype =  bytearray(b'saving')
balance  =  41300.0 

accno =  1005
accnm =  bytearray(b'robert lewandowski')
acctype =  bytearray(b'saving')
balance  =  21600.0 

accno =  1006
accnm =  bytearray(b'gabriel jesus')
acctype =  bytearray(b'fixed')
balance  =  37100.0 

accno =  1008
accnm =  bytearray(b'marcos alonso')
acctype =  bytearray(b'saving')
balance  =  33900.0 

accno =  1009
accnm =  bytearray(b'david luiz')
acctype =  bytearray(b'current')
balance  =  28400.0 

accno =  1010
accnm =  bytearray(b'glenn maxwell')
acctype =  bytearray(b'fixed')
balance  =  61150.0 

accno =  1012
accnm =  bytearray(b'zaheer khan')
acctype =  bytearray(b'saving')
balance  =  22570.0 

accno =  1013
accnm =  bytearray(b'antoine griezman')
acctype =  bytearray(b'fixed')
balance  =  37640.0 

accno =  1014
accnm =  bytearray(b'mesut ozil')
acctype =  bytearray(b'saving')
balance  =  53760.0 

accno =  1015
accnm =  bytearray(b'paul pogba')
acctype =  bytearray(b'saving')
balance  =  67370.0 

accno =  1016
accnm =  bytearray(b'garry cahill')
acctype =  bytearray(b'current')
balance  =  39550.0 

accno =  1017
accnm =  bytearray(b'thibaut courtois')
acctype =  bytearray(b'fixed')
balance  =  97550.0 

accno =  1018
accnm =  bytearray(b'cesar azpilicueta')
acctype =  bytearray(b'current')
balance  =  82716.0 

accno =  1019
accnm =  bytearray(b'cesc fabregas')
acctype =  bytearray(b'current')
balance  =  82716.0 

accno =  1020
accnm =  bytearray(b'ngolo kante')
acctype =  bytearray(b'fixed')
balance  =  55871.0 

accno =  1021
accnm =  bytearray(b'victor moses')
acctype =  bytearray(b'current')
balance  =  63228.0 

accno =  1022
accnm =  bytearray(b'willian')
acctype =  bytearray(b'saving')
balance  =  75961.0 

accno =  1023
accnm =  bytearray(b'pedro')
acctype =  bytearray(b'current')
balance  =  26551.0 

accno =  1024
accnm =  bytearray(b'michy batshuayi')
acctype =  bytearray(b'fixed')
balance  =  63558.0 

accno =  1025
accnm =  bytearray(b'andreas christensen')
acctype =  bytearray(b'saving')
balance  =  68523.0 

accno =  1026
accnm =  bytearray(b'alvaro morata')
acctype =  bytearray(b'saving')
balance  =  96995.0 

accno =  1027
accnm =  bytearray(b'davide zappacosta')
acctype =  bytearray(b'current')
balance  =  49668.0 

accno =  1028
accnm =  bytearray(b'daniel drinkwater')
acctype =  bytearray(b'fixed')
balance  =  75442.0 

accno =  1029
accnm =  bytearray(b'mohamed salah')
acctype =  bytearray(b'saving')
balance  =  83229.0 

accno =  1030
accnm =  bytearray(b'sadio mane')
acctype =  bytearray(b'current')
balance  =  45889.0 

accno =  1031
accnm =  bytearray(b'roberto firmino')
acctype =  bytearray(b'fixed')
balance  =  96321.0 

accno =  1032
accnm =  bytearray(b'alex oxlade chamberlain')
acctype =  bytearray(b'current')
balance  =  58449.0 

accno =  1033
accnm =  bytearray(b'alexandre lacazette')
acctype =  bytearray(b'saving')
balance  =  36227.0 

accno =  1034
accnm =  bytearray(b'raheem sterling')
acctype =  bytearray(b'fixed')
balance  =  62994.0 

accno =  1035
accnm =  bytearray(b'harry kane')
acctype =  bytearray(b'current')
balance  =  78751.0 

accno =  1036
accnm =  bytearray(b'dele alli')
acctype =  bytearray(b'fixed')
balance  =  96637.0 

accno =  1037
accnm =  bytearray(b'hugo lloris')
acctype =  bytearray(b'saving')
balance  =  84552.0 

accno =  1038
accnm =  bytearray(b'bill gates')
acctype =  bytearray(b'current')
balance  =  93119.0 

accno =  1039
accnm =  bytearray(b'amir khan')
acctype =  bytearray(b'saving')
balance  =  66554.0 

accno =  1111
accnm =  bytearray(b'Sam Richards')
acctype =  bytearray(b'savings')
balance  =  20000.0 


--> MySQL connection is closed


        Do you wanna continue(y/n) : n

Exiting Program!!

'''