#Author : Shivam V. Verma
#Assignment No. : 2
#Problem Statement : Inserting given data into Mysql8 database


import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode

#Inserting given data inti accounts, customers and products tables in bankingdb respectively
#Function to insert multiple account details into accounts table
def Insert_accounts(accounts):
    try:
        connection = mysql.connector.connect(host='localhost',
                                       database='bankingdb',
                                       user='root',
                                       password='')
    
        cursor = connection.cursor(prepared=True)
        sql_insert_query ="INSERT INTO accounts(accno, accnm, acctype, balance)" \
                          "VALUES(%s, %s, %s, %s)"
        cursor.executemany(sql_insert_query, accounts)
        connection.commit()
        print ("\n\tRecord inserted successfully into accounts table")
    except mysql.connector.Error as error :
        connection.rollback()
        print("Failed to insert into MySQL table {}".format(error))
    finally:
        #closing database connection.
        if(connection.is_connected()):
            cursor.close()
            connection.close()
            print("\n--> MySQL connection is closed\n")

#Function to insert multiple customer details into customers table
def Insert_customers(customers):
    try:
        connection = mysql.connector.connect(host='localhost',
                                       database='bankingdb',
                                       user='root',
                                       password='')
    
        cursor = connection.cursor(prepared=True)
        sql_insert_query ="INSERT INTO customers(custnm, prodid, paymode)" \
                          "VALUES(%s, %s, %s)"
        cursor.executemany(sql_insert_query, customers)
        connection.commit()
        print ("\n\tRecord inserted successfully into customers table")
    except mysql.connector.Error as error :
        connection.rollback()
        print("Failed to insert into MySQL table {}".format(error))
    finally:
        #closing database connection.
        if(connection.is_connected()):
            cursor.close()
            connection.close()
            print("\n--> MySQL connection is closed\n")

#Function to insert multiple customer details into customers table in selective columns
def Insert_customers1(customers1):
    try:
        connection = mysql.connector.connect(host='localhost',
                                       database='bankingdb',
                                       user='root',
                                       password='')
    
        cursor = connection.cursor(prepared=True)
        sql_insert_query  ="INSERT INTO customers(custnm, prodid)" \
                          "VALUES(%s, %s)"
        cursor.executemany(sql_insert_query, customers1)
        connection.commit()
        print ("\n\tRecord inserted successfully into customers table")
    except mysql.connector.Error as error :
        connection.rollback()
        print("Failed to insert into MySQL table {}".format(error))
    finally:
        #closing database connection.
        if(connection.is_connected()):
            cursor.close()
            connection.close()
            print("\n--> MySQL connection is closed\n")

#Function to insert multiple product details into products table
def Insert_products(products):
    try:
        connection = mysql.connector.connect(host='localhost',
                                       database='bankingdb',
                                       user='root',
                                       password='')
    
        cursor = connection.cursor(prepared=True)
        sql_insert_query ="INSERT INTO products(prodid, prodnm, company, price)" \
                          "VALUES(%s, %s, %s, %s)"
        cursor.executemany(sql_insert_query, products)
        connection.commit()
        print ("\n\tRecord inserted successfully into products table")
    except mysql.connector.Error as error :
        connection.rollback()
        print("Failed to insert into MySQL table {}".format(error))
    finally:
        #closing database connection.
        if(connection.is_connected()):
            cursor.close()
            connection.close()
            print("\n--> MySQL connection is closed\n")

def main():
    #accounts array, having accounts information in the form of tuples
    accounts = [(1001,'sachin tendulkar','saving',45000),(1002,'maria sharapova','fixed',23100),
            (1003,'mitchell johnson','current',15300),(1004,'edan hazard','saving',41300),
            (1005,'robert lewandowski','saving',21600),(1006,'gabriel jesus','fixed',37100),
            (1008,'marcos alonso','saving',33900),(1009,'david luiz','current',28400),
            (1010,'glenn maxwell','fixed',61150),(1012,'zaheer khan','saving',22570),
            (1013,'antoine griezman','fixed',37640),(1014,'mesut ozil','saving',53760),
            (1015,'paul pogba','saving',67370),(1016,'garry cahill','current',39550),
            (1017,'thibaut courtois','fixed',97550),(1018,'cesar azpilicueta','current',82716),
            (1019,'cesc fabregas','current',82716),(1020,'ngolo kante','fixed',55871),
            (1021,'victor moses','current',63228),(1022,'willian','saving',75961),
            (1023,'pedro','current',26551),(1024,'michy batshuayi','fixed',63558),
            (1025,'andreas christensen','saving',68523),(1026,'alvaro morata','saving',96995),
            (1027,'davide zappacosta','current',49668),(1028,'daniel drinkwater','fixed',75442),
            (1029,'mohamed salah','saving',83229),(1030,'sadio mane','current',45889),
            (1031,'roberto firmino','fixed',96321),(1032,'alex oxlade chamberlain','current',58449),
            (1033,'alexandre lacazette','saving',36227),(1034,'raheem sterling','fixed',62994),
            (1035,'harry kane','current',78751),(1036,'dele alli','fixed',96637),
            (1037,'hugo lloris','saving',84552),(1038,'bill gates','current',93119),(1039,'amir khan','saving',66554)]
    
    #customers array, having customers information in the form of tuples
    customers = [('Amir Khan','hp419','netbanking'),
                ('Boris Becker','tg765','cod'),
                ('Rebecca Ferguson','ip627','netbanking'),
                ('Bill Gates','ms488','debit card'),
                ('Tom Cruise','ss210','cod')]
        
    customers1 = [('Michael Schumacher','lt532'),('Arnold Schwarzenegger','hp419'),
                ('Bear Grylls','lt532'),('Mohamed Salah','sg375'),
                ('Ferdinand Porsche','tg765'),('Roger Federer','gt261'),
                ('Vladimir Putin','dm298')]

    #products array, having products information in the form of tuples
    products = [('sp841','Superb','Skoda',2854600.00),
                ('ms488','Surface Pro','microsoft',129399.00),
                ('ip627','iphone 8','apple',64100.00),
                ('hp419','development laptop','HP',54600.00),
                ('ph618','washing machine','philips',23200.00),
                ('lt532','Smart FHD TV','samsung',36500.00),
                ('vn488','Vento','Volkswagen',1325000.00),
                ('x1562','X1 Suv','BMW',3469100.00),
                ('tg765','Tiguan','Volkswagen',2914900.00),
                ('gt261','6 Series GT','BMW',6323200.00)]

    print("\n\t","*"*25,"Insert into bankingdb","*"*25)  
    
    #Calling the Insert_accounts function to enter account details in accounts table
    Insert_accounts(accounts)

    #Calling the Insert_customers function to enter customer details in customers table
    Insert_customers(customers)

    Insert_customers1(customers1)

    #Calling the Insert_products function to enter product details in products table
    Insert_products(products)

    print("Everything's been Inserted successfully!!")

if __name__ == '__main__':
    main()
