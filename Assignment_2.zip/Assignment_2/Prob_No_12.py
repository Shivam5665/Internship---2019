#Author : Shivam V. Verma
#Assignment No. : 2
#Problem No. : 12
#Problem Statement : Display a report using INNER JOIN that will have Customer Name, Product Name, Company, Price

import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode    

print("\n\t","*"*25,"Use of Join","*"*25)  
while True:
    ch = input("\n\tDo you wanna continue(y/n) : ")
    if ch == "y":
        try:
            connection = mysql.connector.connect(host='localhost',
                                        database='bankingdb',
                                        user='root',
                                        password='')
    
            cursor = connection.cursor(prepared=True)
            sql_query = "SELECT c.custnm,p.prodnm,p.company,p.price from customers as c INNER JOIN products as p where c.prodid = p.prodid"
            cursor.execute(sql_query)
            record = cursor.fetchall()
            print("\n")
            for row in record:
                print("Customer_No = ", row[0], )
                print("Product_ No = ", row[1])
                print("Company = ", row[2])
                print("Price = ",row[3],"\n")
        except mysql.connector.Error as error:
            print("Failed to get record from database: {}".format(error))
        finally:
            # closing database connection.
            if (connection.is_connected()):
                cursor.close()
                connection.close()
                print("\n--> MySQL connection is closed\n")
    else:
        print("\nExiting Program!!\n")
        break

#Output:
'''
         ************************* Use of Join *************************

        Do you wanna continue(y/n) : y


Customer_No =  bytearray(b'Amir Khan')
Product_ No =  bytearray(b'development laptop')
Company =  bytearray(b'HP')
Price =  54600.0 

Customer_No =  bytearray(b'Boris Becker')
Product_ No =  bytearray(b'Tiguan')
Company =  bytearray(b'Volkswagen')
Price =  2914900.0 

Customer_No =  bytearray(b'Rebecca Ferguson')
Product_ No =  bytearray(b'iphone 8')
Company =  bytearray(b'apple')
Price =  64100.0 

Customer_No =  bytearray(b'Bill Gates')
Product_ No =  bytearray(b'Surface Pro')
Company =  bytearray(b'microsoft')
Price =  129399.0 

Customer_No =  bytearray(b'Michael Schumacher')
Product_ No =  bytearray(b'Smart FHD TV')
Company =  bytearray(b'samsung')
Price =  36500.0 

Customer_No =  bytearray(b'Arnold Schwarzenegger')
Product_ No =  bytearray(b'development laptop')
Company =  bytearray(b'HP')
Price =  54600.0 

Customer_No =  bytearray(b'Bear Grylls')
Product_ No =  bytearray(b'Smart FHD TV')
Company =  bytearray(b'samsung')
Price =  36500.0 

Customer_No =  bytearray(b'Ferdinand Porsche')
Product_ No =  bytearray(b'Tiguan')
Company =  bytearray(b'Volkswagen')
Price =  2914900.0 

Customer_No =  bytearray(b'Roger Federer')
Product_ No =  bytearray(b'6 Series GT')
Company =  bytearray(b'BMW')
Price =  6323200.0 

Customer_No =  bytearray(b'Amir Khan')
Product_ No =  bytearray(b'development laptop')
Company =  bytearray(b'HP')
Price =  54600.0 

Customer_No =  bytearray(b'Boris Becker')
Product_ No =  bytearray(b'Tiguan')
Company =  bytearray(b'Volkswagen')
Price =  2914900.0 

Customer_No =  bytearray(b'Rebecca Ferguson')
Product_ No =  bytearray(b'iphone 8')
Company =  bytearray(b'apple')
Price =  64100.0 

Customer_No =  bytearray(b'Bill Gates')
Product_ No =  bytearray(b'Surface Pro')
Company =  bytearray(b'microsoft')
Price =  129399.0 

Customer_No =  bytearray(b'Michael Schumacher')
Product_ No =  bytearray(b'Smart FHD TV')
Company =  bytearray(b'samsung')
Price =  36500.0 

Customer_No =  bytearray(b'Arnold Schwarzenegger')
Product_ No =  bytearray(b'development laptop')
Company =  bytearray(b'HP')
Price =  54600.0 

Customer_No =  bytearray(b'Bear Grylls')
Product_ No =  bytearray(b'Smart FHD TV')
Company =  bytearray(b'samsung')
Price =  36500.0 

Customer_No =  bytearray(b'Ferdinand Porsche')
Product_ No =  bytearray(b'Tiguan')
Company =  bytearray(b'Volkswagen')
Price =  2914900.0 

Customer_No =  bytearray(b'Roger Federer')
Product_ No =  bytearray(b'6 Series GT')
Company =  bytearray(b'BMW')
Price =  6323200.0 

Customer_No =  bytearray(b'Amir Khan')
Product_ No =  bytearray(b'development laptop')
Company =  bytearray(b'HP')
Price =  54600.0 

Customer_No =  bytearray(b'Boris Becker')
Product_ No =  bytearray(b'Tiguan')
Company =  bytearray(b'Volkswagen')
Price =  2914900.0 

Customer_No =  bytearray(b'Rebecca Ferguson')
Product_ No =  bytearray(b'iphone 8')
Company =  bytearray(b'apple')
Price =  64100.0 

Customer_No =  bytearray(b'Bill Gates')
Product_ No =  bytearray(b'Surface Pro')
Company =  bytearray(b'microsoft')
Price =  129399.0 

Customer_No =  bytearray(b'Michael Schumacher')
Product_ No =  bytearray(b'Smart FHD TV')
Company =  bytearray(b'samsung')
Price =  36500.0 

Customer_No =  bytearray(b'Arnold Schwarzenegger')
Product_ No =  bytearray(b'development laptop')
Company =  bytearray(b'HP')
Price =  54600.0 

Customer_No =  bytearray(b'Bear Grylls')
Product_ No =  bytearray(b'Smart FHD TV')
Company =  bytearray(b'samsung')
Price =  36500.0 

Customer_No =  bytearray(b'Ferdinand Porsche')
Product_ No =  bytearray(b'Tiguan')
Company =  bytearray(b'Volkswagen')
Price =  2914900.0 

Customer_No =  bytearray(b'Roger Federer')
Product_ No =  bytearray(b'6 Series GT')
Company =  bytearray(b'BMW')
Price =  6323200.0 

Customer_No =  bytearray(b'Amir Khan')
Product_ No =  bytearray(b'development laptop')
Company =  bytearray(b'HP')
Price =  54600.0 

Customer_No =  bytearray(b'Boris Becker')
Product_ No =  bytearray(b'Tiguan')
Company =  bytearray(b'Volkswagen')
Price =  2914900.0 

Customer_No =  bytearray(b'Rebecca Ferguson')
Product_ No =  bytearray(b'iphone 8')
Company =  bytearray(b'apple')
Price =  64100.0 

Customer_No =  bytearray(b'Bill Gates')
Product_ No =  bytearray(b'Surface Pro')
Company =  bytearray(b'microsoft')
Price =  129399.0 

Customer_No =  bytearray(b'Michael Schumacher')
Product_ No =  bytearray(b'Smart FHD TV')
Company =  bytearray(b'samsung')
Price =  36500.0 

Customer_No =  bytearray(b'Arnold Schwarzenegger')
Product_ No =  bytearray(b'development laptop')
Company =  bytearray(b'HP')
Price =  54600.0 

Customer_No =  bytearray(b'Bear Grylls')
Product_ No =  bytearray(b'Smart FHD TV')
Company =  bytearray(b'samsung')
Price =  36500.0 

Customer_No =  bytearray(b'Ferdinand Porsche')
Product_ No =  bytearray(b'Tiguan')
Company =  bytearray(b'Volkswagen')
Price =  2914900.0 

Customer_No =  bytearray(b'Roger Federer')
Product_ No =  bytearray(b'6 Series GT')
Company =  bytearray(b'BMW')
Price =  6323200.0 

Customer_No =  bytearray(b'Amir Khan')
Product_ No =  bytearray(b'development laptop')
Company =  bytearray(b'HP')
Price =  54600.0 

Customer_No =  bytearray(b'Boris Becker')
Product_ No =  bytearray(b'Tiguan')
Company =  bytearray(b'Volkswagen')
Price =  2914900.0 

Customer_No =  bytearray(b'Rebecca Ferguson')
Product_ No =  bytearray(b'iphone 8')
Company =  bytearray(b'apple')
Price =  64100.0 

Customer_No =  bytearray(b'Bill Gates')
Product_ No =  bytearray(b'Surface Pro')
Company =  bytearray(b'microsoft')
Price =  129399.0 

Customer_No =  bytearray(b'Michael Schumacher')
Product_ No =  bytearray(b'Smart FHD TV')
Company =  bytearray(b'samsung')
Price =  36500.0 

Customer_No =  bytearray(b'Arnold Schwarzenegger')
Product_ No =  bytearray(b'development laptop')
Company =  bytearray(b'HP')
Price =  54600.0 

Customer_No =  bytearray(b'Bear Grylls')
Product_ No =  bytearray(b'Smart FHD TV')
Company =  bytearray(b'samsung')
Price =  36500.0 

Customer_No =  bytearray(b'Ferdinand Porsche')
Product_ No =  bytearray(b'Tiguan')
Company =  bytearray(b'Volkswagen')
Price =  2914900.0 

Customer_No =  bytearray(b'Roger Federer')
Product_ No =  bytearray(b'6 Series GT')
Company =  bytearray(b'BMW')
Price =  6323200.0 

Customer_No =  bytearray(b'Amir Khan')
Product_ No =  bytearray(b'development laptop')
Company =  bytearray(b'HP')
Price =  54600.0 

Customer_No =  bytearray(b'Boris Becker')
Product_ No =  bytearray(b'Tiguan')
Company =  bytearray(b'Volkswagen')
Price =  2914900.0 

Customer_No =  bytearray(b'Rebecca Ferguson')
Product_ No =  bytearray(b'iphone 8')
Company =  bytearray(b'apple')
Price =  64100.0 

Customer_No =  bytearray(b'Bill Gates')
Product_ No =  bytearray(b'Surface Pro')
Company =  bytearray(b'microsoft')
Price =  129399.0 

Customer_No =  bytearray(b'Michael Schumacher')
Product_ No =  bytearray(b'Smart FHD TV')
Company =  bytearray(b'samsung')
Price =  36500.0 

Customer_No =  bytearray(b'Arnold Schwarzenegger')
Product_ No =  bytearray(b'development laptop')
Company =  bytearray(b'HP')
Price =  54600.0 

Customer_No =  bytearray(b'Bear Grylls')
Product_ No =  bytearray(b'Smart FHD TV')
Company =  bytearray(b'samsung')
Price =  36500.0 

Customer_No =  bytearray(b'Ferdinand Porsche')
Product_ No =  bytearray(b'Tiguan')
Company =  bytearray(b'Volkswagen')
Price =  2914900.0 

Customer_No =  bytearray(b'Roger Federer')
Product_ No =  bytearray(b'6 Series GT')
Company =  bytearray(b'BMW')
Price =  6323200.0 


--> MySQL connection is closed


        Do you wanna continue(y/n) : n

Exiting Program!!

'''