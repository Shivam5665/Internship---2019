#Author : Shivam V. Verma
#Assignment No. : 2
#Problem No. : 4
#Problem Statement : to accept account number, transaction type (deposit/withdraw) and amount from the user 
# and update balance of the account holder depending on the transaction type. 
# Store details like accno, trtype, amount & transaction date in a transaction table. 
# Display the modified record. Display message if account does not exist.


import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode
import time

def get_acc_details(accno,trans_type,amount):
    try:
        connection = mysql.connector.connect(host='localhost',
                                       database='bankingdb',
                                       user='root',
                                       password='')
        
        cursor = connection.cursor(prepared=True)
        
        sql_select_query = "SELECT * FROM accounts WHERE accno = {}".format(accno)
        cursor.execute(sql_select_query)
        record = cursor.fetchall()
        if record == None:
            print("Sorry! Match not found!!")
        else:
            s = time.strftime('%Y-%m-%d')
            sql_insert_query = "INSERT INTO transaction(accno,trtype,amount,transaction_date) VALUES({},'{}','{}','{}')".format(accno, trans_type, amount, s)
            cursor.execute(sql_insert_query)
            print("Data inserted successfully")
            temp_qry  = "Select * from transaction where accno = {}".format(accno)
            cursor.execute(temp_qry)
            record = cursor.fetchall()
            print("\n")
            for row in record:
                print("accno = ", row[0], )
                print("trtype = ", row[1])
                print("amount = ", row[2])
                print("transaction_date  = ", row[3], "\n")
    except mysql.connector.Error as error:
        print("Failed to get record from database: {}".format(error))                                                                                                           
    finally:
        # closing database connection.
        if (connection.is_connected()):
            cursor.close()
            connection.close()
            print("\n--> MySQL connection is closed\n")

print("\n\t","*"*25,"Transaction Update","*"*25)  
while True:
    row = []
    ch = input("\n\tDo you wanna continue(y/n) : ")
    if ch == "y":
        accno = input("\nEnter account number : ")
        trans_type = str(input("Enter transaction type(deposit/withdraw) : "))
        amount = float(input("Enter amount : "))
        get_acc_details(accno,trans_type,amount)
    else:
        print("\nExiting Program!!\n")
        break
#Ouptut:
'''
        ************************* Transaction Update *************************

        Do you wanna continue(y/n) : y

Enter account number : 1007 
Enter transaction type(deposit/withdraw) : deposit
Enter amount : 13000
Data inserted successfully


accno =  1007
trtype =  bytearray(b'deposit')
amount =  13000
transaction_date  =  2019-06-19 


--> MySQL connection is closed


        Do you wanna continue(y/n) : n   

Exiting Program!!
'''