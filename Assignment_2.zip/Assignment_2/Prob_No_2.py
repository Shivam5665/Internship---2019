#Author : Shivam V. Verma
#Assignment No. : 2
#Problem No. : 2
#Problem Statement : to show list of all accounts from the DB table

import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode

def dis_allaccounts():
    try:
        connection = mysql.connector.connect(host='localhost',
                                       database='bankingdb',
                                       user='root',
                                       password='')
        
        cursor = connection.cursor(prepared=True)
        
        sql_select_query = "SELECT * FROM accounts"
        cursor.execute(sql_select_query)
        record = cursor.fetchall()
        for row in record:
            print("\naccno = ", row[0], )
            print("accnm = ", row[1])
            print("acctype = ", row[2])
            print("balance  = ", row[3], "\n")
    except mysql.connector.Error as error:
        print("Failed to get record from database: {}".format(error))
    finally:
        # closing database connection.
        if (connection.is_connected()):
            cursor.close()
            connection.close()
            print("\n--> MySQL connection is closed\n")

print("\n\t","*"*25,"Display all accounts","*"*25)  
dis_allaccounts()

#Output:
'''
         ************************* Display all accounts *************************

accno =  1001
accnm =  bytearray(b&apos;sachin tendulkar&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  45000.0 


accno =  1002
accnm =  bytearray(b&apos;maria sharapova&apos;)
acctype =  bytearray(b&apos;fixed&apos;)
balance  =  23100.0 


accno =  1003
accnm =  bytearray(b&apos;mitchell johnson&apos;)
acctype =  bytearray(b&apos;current&apos;)
balance  =  15300.0 


accno =  1004
accnm =  bytearray(b&apos;edan hazard&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  41300.0 


accno =  1005
accnm =  bytearray(b&apos;robert lewandowski&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  21600.0 


accno =  1006
accnm =  bytearray(b&apos;gabriel jesus&apos;)
acctype =  bytearray(b&apos;fixed&apos;)
balance  =  37100.0 


accno =  1008
accnm =  bytearray(b&apos;marcos alonso&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  33900.0 


accno =  1009
accnm =  bytearray(b&apos;david luiz&apos;)
acctype =  bytearray(b&apos;current&apos;)
balance  =  28400.0 


accno =  1010
accnm =  bytearray(b&apos;glenn maxwell&apos;)
acctype =  bytearray(b&apos;fixed&apos;)
balance  =  61150.0 


accno =  1012
accnm =  bytearray(b&apos;zaheer khan&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  22570.0 


accno =  1013
accnm =  bytearray(b&apos;antoine griezman&apos;)
acctype =  bytearray(b&apos;fixed&apos;)
balance  =  37640.0 


accno =  1014
accnm =  bytearray(b&apos;mesut ozil&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  53760.0 


accno =  1015
accnm =  bytearray(b&apos;paul pogba&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  67370.0 


accno =  1016
accnm =  bytearray(b&apos;garry cahill&apos;)
acctype =  bytearray(b&apos;current&apos;)
balance  =  39550.0 


accno =  1017
accnm =  bytearray(b&apos;thibaut courtois&apos;)
acctype =  bytearray(b&apos;fixed&apos;)
balance  =  97550.0 


accno =  1018
accnm =  bytearray(b&apos;cesar azpilicueta&apos;)
acctype =  bytearray(b&apos;current&apos;)
balance  =  82716.0 


accno =  1019
accnm =  bytearray(b&apos;cesc fabregas&apos;)
acctype =  bytearray(b&apos;current&apos;)
balance  =  82716.0 


accno =  1020
accnm =  bytearray(b&apos;ngolo kante&apos;)
acctype =  bytearray(b&apos;fixed&apos;)
balance  =  55871.0 


accno =  1021
accnm =  bytearray(b&apos;victor moses&apos;)
acctype =  bytearray(b&apos;current&apos;)
balance  =  63228.0 


accno =  1022
accnm =  bytearray(b&apos;willian&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  75961.0 


accno =  1023
accnm =  bytearray(b&apos;pedro&apos;)
acctype =  bytearray(b&apos;current&apos;)
balance  =  26551.0 


accno =  1024
accnm =  bytearray(b&apos;michy batshuayi&apos;)
acctype =  bytearray(b&apos;fixed&apos;)
balance  =  63558.0 


accno =  1025
accnm =  bytearray(b&apos;andreas christensen&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  68523.0 


accno =  1026
accnm =  bytearray(b&apos;alvaro morata&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  96995.0 


accno =  1027
accnm =  bytearray(b&apos;davide zappacosta&apos;)
acctype =  bytearray(b&apos;current&apos;)
balance  =  49668.0 


accno =  1028
accnm =  bytearray(b&apos;daniel drinkwater&apos;)
acctype =  bytearray(b&apos;fixed&apos;)
balance  =  75442.0 


accno =  1029
accnm =  bytearray(b&apos;mohamed salah&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  83229.0 


accno =  1030
accnm =  bytearray(b&apos;sadio mane&apos;)
acctype =  bytearray(b&apos;current&apos;)
balance  =  45889.0 


accno =  1031
accnm =  bytearray(b&apos;roberto firmino&apos;)
acctype =  bytearray(b&apos;fixed&apos;)
balance  =  96321.0 


accno =  1032
accnm =  bytearray(b&apos;alex oxlade chamberlain&apos;)
acctype =  bytearray(b&apos;current&apos;)
balance  =  58449.0 


accno =  1033
accnm =  bytearray(b&apos;alexandre lacazette&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  36227.0 


accno =  1034
accnm =  bytearray(b&apos;raheem sterling&apos;)
acctype =  bytearray(b&apos;fixed&apos;)
balance  =  62994.0 


accno =  1035
accnm =  bytearray(b&apos;harry kane&apos;)
acctype =  bytearray(b&apos;current&apos;)
balance  =  78751.0 


accno =  1036
accnm =  bytearray(b&apos;dele alli&apos;)
acctype =  bytearray(b&apos;fixed&apos;)
balance  =  96637.0 


accno =  1037
accnm =  bytearray(b&apos;hugo lloris&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  84552.0 


accno =  1038
accnm =  bytearray(b&apos;bill gates&apos;)
acctype =  bytearray(b&apos;current&apos;)
balance  =  93119.0 


accno =  1039
accnm =  bytearray(b&apos;amir khan&apos;)
acctype =  bytearray(b&apos;saving&apos;)
balance  =  66554.0 


accno =  1111
accnm =  bytearray(b&apos;Sam Richards&apos;)
acctype =  bytearray(b&apos;savings&apos;)
balance  =  20000.0 


--&gt; MySQL connection is closed
</pre>
'''