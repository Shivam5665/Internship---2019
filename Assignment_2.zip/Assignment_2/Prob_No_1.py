#Author : Shivam V. Verma
#Assignment No. : 2
#Problem No. : 1
#Problem Statement : to accept account details from the user and add the record to the accounts table of DB

import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode

def Insert_newacc(accno, accnm, acctype, balance):
    try:
        connection = mysql.connector.connect(host='localhost',
                                       database='bankingdb',
                                       user='root',
                                       password='')
    
        cursor = connection.cursor(prepared=True)

        sql_insert_query ="INSERT INTO accounts(accno, accnm, acctype, balance)" \
                          "VALUES(%s, %s, %s, %s)"
        
        ins_tuple = (accno, accnm, acctype, balance)
        cursor.execute(sql_insert_query,ins_tuple)
        connection.commit()
        print ("\n\tRecord inserted successfully into accounts table")
    except mysql.connector.Error as error :
        connection.rollback()
        print("Failed to insert into MySQL table {}".format(error))
    finally:
        #closing database connection.
        if(connection.is_connected()):
            cursor.close()
            connection.close()
            print("\n--> MySQL connection is closed\n")

def get_acc_details(accno):
    try:
        connection = mysql.connector.connect(host='localhost',
                                       database='bankingdb',
                                       user='root',
                                       password='')
        
        cursor = connection.cursor(prepared=True)
        
        sql_select_query = "SELECT * FROM accounts WHERE accno = {}".format(accno)
        cursor.execute(sql_select_query)
        record = cursor.fetchall()
        for row in record:
            print("accno = ", row[0], )
            print("accnm = ", row[1])
            print("acctype = ", row[2])
            print("balance  = ", row[3], "\n")
    except mysql.connector.Error as error:
        print("Failed to get record from database: {}".format(error))
    finally:
        # closing database connection.
        if (connection.is_connected()):
            cursor.close()
            connection.close()
            print("\n--> MySQL connection is closed\n")

def main():
    print("\n\t","*"*25,"Insert into Accounts","*"*25)  
    while True:
        print("\n\tChoose your operation:\n\t1. Add account details\n\t2. Print account details\n\t3. Exit\n")
        ch = int(input("Enter your choice: "))
        if ch == 1:
            print("\nEnter account details below:\n")
            accno = int(input("Enter account number (eg.1001): "))
            accnm = input("Enter account holder's name : ")
            acctype = input("Enter account type : (current/savings/fixed): ")
            balance = float(input("Enter balance in Rs. : "))
            Insert_newacc(accno, accnm, acctype, balance)
        elif ch == 2:
            accno = int (input("\nEnter account number(eg.1001) : "))
            get_acc_details(accno)
        else:
            print("\nExiting Program!!\n")
            break



if __name__ == '__main__':
    main()

#Output: 
'''
         ************************* Insert into Accounts *************************

       Choose your operation:
        1. Add account details
        2. Print account details
        3. Exit

Enter your choice: 1

Enter account details below:

Enter account number (eg.1001): 1111
Enter account holder's name : Sam Richards
Enter account type : (current/savings/fixed): saving
Enter balance in Rs. : 20000

        Record inserted successfully into accounts table

--> MySQL connection is closed

        Choose your operation:
        1. Add account details
        2. Print account details
        3. Exit

Enter your choice: 2

Enter account number(eg.1001) : 1111
accno =  1111
accnm =  bytearray(b'Sam Richards')
acctype =  bytearray(b'savings')
balance  =  20000.0 

--> MySQL connection is closed

Choose your operation:
        1. Add account details
        2. Print account details
        3. Exit

Enter your choice: 3

Exiting Program!!

'''