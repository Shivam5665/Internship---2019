#Author : Shivam V. Verma
#Assignment No. : 2
#Problem No. : 3
#Problem Statement : to accept account number from the user and search the record in the database. If found display data else display appropriate message.

import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode

def get_acc_details(accno):
    try:
        connection = mysql.connector.connect(host='localhost',
                                       database='bankingdb',
                                       user='root',
                                       password='')
        
        cursor = connection.cursor(prepared=True)
        
        sql_select_query = "SELECT * FROM accounts WHERE accno = {}".format(accno)
        cursor.execute(sql_select_query)
        record = cursor.fetchall()
        if record == []:
            print("Sorry! Match not found!!")
        else:
            for row in record:
                print("accno = ", row[0], )
                print("accnm = ", row[1])
                print("acctype = ", row[2])
                print("balance  = ", row[3], "\n")
    except mysql.connector.Error as error:
        print("Failed to get record from database: {}".format(error))
    finally:
        # closing database connection.
        if (connection.is_connected()):
            cursor.close()
            connection.close()
            print("\n--> MySQL connection is closed\n")

print("\n\t","*"*25,"Search your account","*"*25)  
while True:
    ch = input("\n\tDo you wanna continue(y/n) : ")
    if ch == "y":
        accnm = input("\nEnter account number : ")
        get_acc_details(accnm)
    else:
        print("\nExiting Program!!\n")
        break

#Output:
'''
         ************************* Search your account *************************

        Do you wanna continue(y/n) : y

Enter account number : 1001
accno =  1001
accnm =  bytearray(b'sachin tendulkar')
acctype =  bytearray(b'saving')
balance  =  45000.0 


--> MySQL connection is closed


        Do you wanna continue(y/n) : y

Enter account number : 1111
accno =  1111
accnm =  bytearray(b'Sam Richards')
acctype =  bytearray(b'savings')
balance  =  20000.0 


--> MySQL connection is closed

        Do you wanna continue(y/n) : y

Enter account number : 1212
Sorry! Match not found!!

--> MySQL connection is closed

        Do you wanna continue(y/n) : n

Exiting Program!!

'''