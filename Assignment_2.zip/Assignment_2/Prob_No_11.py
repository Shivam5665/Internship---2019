#Author : Shivam V. Verma
#Assignment No. : 2
#Problem No. : 11
#Problem Statement : to display a report that contains -
#Account type, total account holders in that type, total of balance, maximum balance of that type

import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode    

print("\n\t","*"*25,"Acctype Report","*"*25)  
while True:
    ch = input("\n\tDo you want t print report(y/n) : ")
    if ch == "y":
        try:
            connection = mysql.connector.connect(host='localhost',
                                        database='bankingdb',
                                        user='root',
                                        password='')
    
            cursor = connection.cursor(prepared=True)
            print("\n")
            sql_query = "SELECT acctype,COUNT(accno),SUM(balance) from accounts Group BY(acctype)"
            cursor.execute(sql_query)
            record = cursor.fetchall()
            for row in record:
                print(row)
        except mysql.connector.Error as error:
            print("Failed to get record from database: {}".format(error))
        finally:
            # closing database connection.
            if (connection.is_connected()):
                cursor.close()
                connection.close()
                print("\n--> MySQL connection is closed\n")
    else:
        print("\nExiting Program!!\n")
        break


#Output:
'''
        ************************* Acctype Report *************************

        Do you want t print report(y/n) : y

(bytearray(b'saving'), 15, 817541.0)
(bytearray(b'fixed'), 11, 707363.0)
(bytearray(b'current'), 12, 664337.0)

--> MySQL connection is closed


        Do you want t print report(y/n) : n

Exiting Program!!

'''