#Author : Shivam V. Verma
#Assignment No. : 2
#Problem No. : 5
#Problem Statement : to update all account holders balance by adding interest based on their account type 
#	saving 3%
#	fixed 7%
#	current 4%
#NOTE: Create a stored procedure in the DB and call the procedure in the program for updations.

import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode
from pprint import pprint

'''
    ----------------------------------------------- Stored Procedures ------------------------------------------------
    Delimiter //
    create DEFINER='root'@'localhost' procedure bal_update_saving() 
    Begin 
    Update accounts set balance = balance + balance * 0.03 where acctype = 'saving';
    END //

    Delimiter //
    create DEFINER='root'@'localhost' procedure bal_update_fixed() 
    Begin 
    Update accounts set balance = balance + balance * 0.07 where acctype = 'fixed';
    END // 

    Delimiter //
    create DEFINER='root'@'localhost' procedure bal_update_current() 
    Begin 
    Update accounts set balance = balance + balance * 0.04 where acctype = 'current';
    END //

'''

try:
    connection = mysql.connector.connect(host='localhost',
                                database='bankingdb',
                                user='root',
                                password='')
    cursor = connection.cursor()
    print("\n\t-->Updating Saving Accounts...\n")
    cursor.callproc("bal_update_saving",[])
    for result in cursor.stored_results():
        pprint(result.fetchall())
    print("\n\t Saving Accounts updated")

    print("\n\t-->Updating fixed Accounts...\n")
    cursor.callproc("bal_update_fixed",[])
    for result in cursor.stored_results():
        pprint(result.fetchall())
    print("\n\t Fixed Accounts updated")
    
    print("\n\t-->Updating Current Accounts...\n")
    cursor.callproc("bal_update_current",[])
    for result in cursor.stored_results():
        pprint(result.fetchall())    
    print("\n\t Current Accounts updated")

except mysql.connector.Error as error:
    print("Failed to execute stored procedure: {}".format(error))
finally:
    # closing database connection.
    if (connection.is_connected()):
        cursor.close()
        connection.close()
        print("\n\t-->Mysql connection is closed")

#Output:
'''
mysql> call bal_update_saving()//                                               
Query OK, 14 rows affected (0.25 sec)

mysql> call bal_update_fixed()//
Query OK, 11 rows affected (0.16 sec)

mysql> call bal_update_current()//
Query OK, 12 rows affected (0.18 sec)

mysql> select * from accounts //
+-------+-------------------------+---------+---------+
| accno | accnm                   | acctype | balance |
+-------+-------------------------+---------+---------+
|  1001 | sachin tendulkar        | saving  |   46350 |
|  1002 | maria sharapova         | fixed   |   24717 |
|  1003 | mitchell johnson        | current |   15912 |
|  1004 | edan hazard             | saving  |   42539 |
|  1005 | robert lewandowski      | saving  |   22248 |
|  1006 | gabriel jesus           | fixed   |   39697 |
|  1008 | marcos alonso           | saving  |   34917 |
|  1009 | david luiz              | current |   29536 |
|  1010 | glenn maxwell           | fixed   | 65430.5 |
|  1012 | zaheer khan             | saving  | 23247.1 |
|  1013 | antoine griezman        | fixed   | 40274.8 |
|  1014 | mesut ozil              | saving  | 55372.8 |
|  1015 | paul pogba              | saving  | 69391.1 |
|  1016 | garry cahill            | current |   41132 |
|  1017 | thibaut courtois        | fixed   |  104378 |
|  1018 | cesar azpilicueta       | current | 86024.6 |
|  1019 | cesc fabregas           | current | 86024.6 |
|  1020 | ngolo kante             | fixed   |   59782 |
|  1021 | victor moses            | current | 65757.1 |
|  1022 | willian                 | saving  | 78239.8 |
|  1023 | pedro                   | current |   27613 |
|  1024 | michy batshuayi         | fixed   | 68007.1 |
|  1025 | andreas christensen     | saving  | 70578.7 |
|  1026 | alvaro morata           | saving  | 99904.9 |
|  1027 | davide zappacosta       | current | 51654.7 |
|  1028 | daniel drinkwater       | fixed   | 80722.9 |
|  1029 | mohamed salah           | saving  | 85725.9 |
|  1030 | sadio mane              | current | 47724.6 |
|  1031 | roberto firmino         | fixed   |  103063 |
|  1032 | alex oxlade chamberlain | current |   60787 |
|  1033 | alexandre lacazette     | saving  | 37313.8 |
|  1034 | raheem sterling         | fixed   | 67403.6 |
|  1035 | harry kane              | current |   81901 |
|  1036 | dele alli               | fixed   |  103402 |
|  1037 | hugo lloris             | saving  | 87088.6 |
|  1038 | bill gates              | current | 96843.8 |
|  1039 | amir khan               | saving  | 68550.6 |
+-------+-------------------------+---------+---------+
37 rows in set (0.00 sec)


'''